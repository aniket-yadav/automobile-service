<?php
require('init.php');

$id = $_POST['id'];

$res = array();
$sql="DELETE FROM `services`  WHERE `serviceid`='$id'";


$result=mysqli_query($conn,$sql);

if($result){
$res['success']=true;
$res['message']="Record deleted";
}else{
$res['success']=false;
$res['message']="Failed to delete";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>



<!DOCTYPE HTML>
<html>  
<body>

<form action="add_admin.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Mobile: <input type="text" name="mobile"><br>

<input type="submit">
</form>

</body>
</html>
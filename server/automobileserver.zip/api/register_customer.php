<?php
require('init.php');
$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$customerid = uniqid("cu");


function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $pass ="";
    $alphaLength = strlen($alphabet) - 1; 
 for ($i = 0; $i < 8; $i++) {
     $pass.= $alphabet[random_int(0, $alphaLength)];
    }
    return $pass;
}

$password=randomPassword();
$username = strstr($email,'@',true);
$mdpass = md5($password);




$sql ="INSERT INTO `customers` (`username`,`name`,`password`,`mobile`,`customerid`,`email`) VALUES('$username','$name','$mdpass','$mobile','$customerid','$email')";


$result=mysqli_query($conn,$sql);

$res =array();
if($result){
$to = $email;
					$subject = "Registration successful";

					$message = "Hello,
					User<br>
					Your account is created with Automobile Service<br><br>
					Your password is given below:-<br>
					Username:-$username<br>
					Password:-$password<br>
					
					Thank You<br>
					from Automobile Service team";

					$header = "From:automobileservice \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						
$res['success'] = true;
$res['message'] = "Successful";
						
					}
}else{
$res['success'] = false;
$res['message'] = "Failed";

}
echo json_encode($res);

mysqli_close($conn);
?>



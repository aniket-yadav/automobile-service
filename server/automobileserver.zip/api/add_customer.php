<?php
require('init.php');

$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$address = $_POST['address'];
$city = $_POST['city'];
$district = $_POST['district'];
$pincode = $_POST['pincode'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$fcmtoken = $_POST['fcmtoken'];
$image = $_POST['image'];
$username = strstr($email,'@',true);
$password = md5("12345678");
$customerid = uniqid("cu");

$sql="insert into customers(customerid,name,email,mobile,username,address,city,district,pincode,latitude,longitude,fcmtoken,image,password)values('$customerid','$name','$email','$mobile','$username','$address','$city','$district','$pincode','$latitude','$longitude','$fcmtoken','$image','$password')";
$result=mysqli_query($conn,$sql);

$res = array();
if($result){
$res['success']=true;
$res['message']="user created!";
}else{
$res['success']=false;
$res['message']="Faild to create user";
}
echo json_encode($res);
?>
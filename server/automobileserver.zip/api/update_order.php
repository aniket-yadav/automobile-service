<?php
require('init.php');
$id = $_POST['id'];
$paymentStatus = $_POST['paymentStatus'];
$status = $_POST['status'];

$res = array();

    $sql = "UPDATE `reports` SET `paymentstatus`='$paymentStatus',  `status`='$status' WHERE `reportid`='$id'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>



<?php
require('init.php');

$id = $_POST['id'];
$image = $_POST['image'];
$res = array();
$sql="";

if(strlen($image) > 0){
    
$upload="https://automobileservice.tech/api/images/$id.jpeg";    
}else{
    
$upload = '';
}

$upload_Path="images/$id.jpeg";


    $sql = "UPDATE `servicecenter` SET `image`='$upload' WHERE `centerid`='$id'";


$result=mysqli_query($conn,$sql);


if($result){
    if(strlen($image) > 0){
file_put_contents($upload_Path,base64_decode($image));
}else{
 unlink($upload_Path);
}

$res['success']=true;
$res['message']="Profile photo updated";
$res['upload'] = $upload;
$res[i] = strlen($image);
}else{
$res['success']=false;
$res['message']="Failed to update profile photo";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>



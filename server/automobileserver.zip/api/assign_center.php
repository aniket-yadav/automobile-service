<?php
require('init.php');
$managerid = $_POST['managerid'];
$manager = $_POST['manager'];
$centerid = $_POST['centerid'];
$center = $_POST['center'];


$sql ="update `managers` set `servicecenterid`='$centerid' where `managerid` = '$managerid' ";


$result=mysqli_query($conn,$sql);

$res =array();
if($result){
    
    $sql2 ="update `servicecenter` set `managerid`='$managerid' where `centerid` = '$centerid'";


$result2=mysqli_query($conn,$sql2);
if($result2){
$to = $email;
					$subject = "Service center Assigned";

					$message = "Hello,
					Manager $manager <br>
					You have been assigned to new service center<br><br>
					Your new service center is:-<br>
					$center<br>
					
					
					Thank You<br>
					from Automobile Service team";

					$header = "From:automobileservice \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						
$res['success'] = true;
$res['message'] = "Successful";
						
					}else{
					    $res['success'] = true;
$res['message'] = "Successful";
					}
    
}else{
$res['success'] = false;
$res['message'] = "Failed";    
}

}else{
$res['success'] = false;
$res['message'] = "Failed";

}
echo json_encode($res);

mysqli_close($conn);
?>



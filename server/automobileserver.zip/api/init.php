<?php

    $server = "localhost";
    $user = "u117653321_Nikhil";
    $password = "Nikhil@123";
    $database = "u117653321_automobile";
    $conn = mysqli_connect($server, $user, $password, $database);

?>
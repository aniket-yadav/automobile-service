<?php
require('init.php');

$email = $_POST['email'];

$username=substr($email,0,strpos($email,'@'));

$sql2="select `role` from `users` where `username`='$username'";

$result2=mysqli_query($conn,$sql2);

$res =array();
if($result2){
$row=mysqli_fetch_assoc($result2);
    $role=$row['role'];
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $pass ="";
    $alphaLength = strlen($alphabet) - 1; 
 for ($i = 0; $i < 8; $i++) {
     $pass.= $alphabet[random_int(0, $alphaLength)];
    }
    return $pass;
}

$password=randomPassword();
$mdpass = md5($password);


$sql="";

if($role == "admin"){
    $sql = "UPDATE `admin` SET `password`='$mdpass' WHERE `email`='$email'";
}else if($role == "manager"){
    $sql = "UPDATE `managers` SET `password`='$mdpass' WHERE `email`='$email'";
}else if($role == "customer"){
    $sql = "UPDATE `customers` SET `password`='$mdpass' WHERE `email`='$email'";
}


$result=mysqli_query($conn,$sql);


if($result){
$to = $email;
					$subject = "Username and Password";

					$message = "Hello,
					User<br>
					Your password has been reset.<br><br>
					Your password is given below:-<br>
					Username:-$username<br>
					Password:-$password<br>
					
					Thank You<br>
					from Automobile service team";

					$header = "From:automobileservice \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						
$res['success'] = true;
$res['message'] = "Password reset";
						
					}
}else{
$res['success'] = false;
$res['message'] = "Failed to reset password";
$res['role']=$role;

}
}else{
$res['success'] = false;
$res['message'] = "Email not found";

}

echo json_encode($res);

mysqli_close($conn);
?>
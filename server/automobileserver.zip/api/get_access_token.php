<?php
$amount = $_POST['amount'];

$cashfree_id = '1929881525ae4b356a1e187b4a889291';
$cashfree_secret = 'b47ee150d2719b8200f67a524ef52896cc6898c7';
$orderid = uniqid("pay");

$url = 'https://test.cashfree.com/api/v2/cftoken/order';

$headers = array(
    'Content-Type:application/json',
    'x-client-id :'. $cashfree_id,
    'x-client-secret:'. $cashfree_secret,
);
$json_data = [
    "orderId" => $orderid,
    "orderAmount"=> $amount,
          "orderCurrency"=> "INR",
    ];
    
    $data = json_encode($json_data);

$res = array();

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$result = curl_exec($ch);
if ($result === FALSE) {
    die('Oops! failed: ' . curl_error($ch));
}
// parse_str($result, $output);
$output = json_decode($result,true);
$res['orderid'] = $orderid;
$res['id'] = $cashfree_id;
$res['mode'] = "TEST";
$res['success'] = $output != FALSE;
$res['message'] = $output['message'];
$res['cftoken'] = $output['cftoken'];
echo json_encode($res);
curl_close($ch);
?>
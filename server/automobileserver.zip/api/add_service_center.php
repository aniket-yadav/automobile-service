<?php
require('init.php');
$name = $_POST['name'];
$address = $_POST['address'];
$district = $_POST['district'];
$city = $_POST['city'];
$pincode = $_POST['pincode'];
$lat = $_POST['lat'];
$long = $_POST['lng'];
$centerid = uniqid("cen");


$sql ="INSERT INTO `servicecenter` (`centerid`, `name`,  `address`, `city`, `district`, `pincode`, `latitude`, `longitude`) VALUES('$centerid','$name','$address','$city','$district','$pincode','$lat','$long')";


$result=mysqli_query($conn,$sql);

$res =array();
if($result){
$res['success'] = true;
$res['message'] = "Successful";
						

}else{
$res['success'] = false;
$res['message'] = "Failed";
$res['sql'] =$sql;

}
echo json_encode($res);


?>



<?php
require('init.php');
$id = $_POST['id'];
$name = $_POST['name'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$district = $_POST['district'];
$city = $_POST['city'];
$lat = $_POST['lat'];
$lng = $_POST['lng'];

$res = array();

    $sql = "UPDATE `servicecenter` SET  `name` = '$name', `address`='$address', `pincode`='$pincode', `city`='$city', `district`= '$district', `pincode`='$pincode', `latitude`= '$lat',`longitude`='$lng' WHERE `centerid`='$id'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>



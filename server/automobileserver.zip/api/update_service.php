<?php
require('init.php');
$id = $_POST['id'];
$name = $_POST['name'];
$charge = $_POST['charge'];

$res = array();

    $sql = "UPDATE `services` SET `name`='$name',  `charge`='$charge' WHERE `serviceid`='$id'";


$result=mysqli_query($conn,$sql);


if($result){
$res['success']=true;
$res['message']="Successful";
}else{
$res['success']=false;
$res['message']="Failed";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>



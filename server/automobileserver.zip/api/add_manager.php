<?php
require('init.php');
$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$managerid = uniqid("ma");


function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $pass ="";
    $alphaLength = strlen($alphabet) - 1; 
 for ($i = 0; $i < 8; $i++) {
     $pass.= $alphabet[random_int(0, $alphaLength)];
    }
    return $pass;
}

$password=randomPassword();
$username=substr($email,0,strpos($email,'@'));
$mdpass = md5($password);




$sql ="INSERT INTO `managers` (`managerid`, `name`, `email`, `mobile`, `username`,  `password`, `role`) VALUES ('$managerid', '$name', '$email', '$mobile', '$username',  '$mdpass', 'manager')";


$result=mysqli_query($conn,$sql);

$res =array();
if($result){
$to = $email;
					$subject = "Registration successful";

					$message = "Hello,
					Manager $name<br>
					Your account is created with Automobile Service<br><br>
					Your password is given below:-<br>
					Username:-$username<br>
					Password:-$password<br>
					
					Thank You<br>
					from Automobile Service team";

					$header = "From:automobileservice \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					if( mail($to,$subject,$message,$header)){
						
$res['success'] = true;
$res['message'] = "Successful";
						
					}
}else{
$res['success'] = false;
$res['message'] = "Failed";
$res['err'] = mysqli_connect_error();


}
echo json_encode($res);

?>



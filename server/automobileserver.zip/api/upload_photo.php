<?php
require('init.php');
$role = $_POST['role'];
$userId = $_POST['userid'];
$image = $_POST['image'];
$res = array();
$sql="";

if(strlen($image) > 0){
    
$upload="https://automobileservice.tech/api/images/$userId.jpeg";    
}else{
    
$upload = '';
}

$upload_Path="images/$userId.jpeg";

if($role == "admin"){
    $sql = "UPDATE `admin` SET `image`='$upload' WHERE `adminid`='$userId'";
}else if($role == "manager"){
    $sql = "UPDATE `managers` SET `image`='$upload' WHERE `managerid`='$userId'";
}else if($role == "customer"){
    $sql = "UPDATE `customers` SET `image`='$upload' WHERE `customerid`='$userId'";
}


$result=mysqli_query($conn,$sql);


if($result){
    if(strlen($image) > 0){
file_put_contents($upload_Path,base64_decode($image));
}else{
 unlink($upload_Path);
}

$res['success']=true;
$res['message']="Profile photo updated";
$res['upload'] = $upload;
$res[i] = strlen($image);
}else{
$res['success']=false;
$res['message']="Failed to update profile photo";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>



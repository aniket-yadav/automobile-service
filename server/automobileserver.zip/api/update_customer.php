<?php
require('init.php');
$userid = $_POST['userid'];
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$address = $_POST['address'];
$district = $_POST['district'];
$city = $_POST['city'];
$pincode = $_POST['pincode'];



    $sql = "UPDATE `customers` SET `name`='$name',`mobile`='$mobile',`address`='$address',`district` ='$district',`city`='$city',`pincode`='$pincode' WHERE `customerid`='$userid'";


$result=mysqli_query($conn,$sql);

$res =array();
if($result){
$res['success'] = true;
$res['message'] = "Profile updated";
						

}else{
$res['success'] = false;
$res['message'] = "Failed to update";

						
}
echo json_encode($res);


?>



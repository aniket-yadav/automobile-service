<?php
require('init.php');
$name = $_POST['name'];
$charge = $_POST['charge'];
$serviceid = uniqid("ser");







$sql ="INSERT INTO `services` (`name`,`charge`,`serviceid`) VALUES('$name','$charge','$serviceid')";


$result=mysqli_query($conn,$sql);

$res =array();
if($result){
$res['success'] = true;
$res['message'] = "Successful";
						

}else{
$res['success'] = false;
$res['message'] = "Failed";

}
echo json_encode($res);


?>



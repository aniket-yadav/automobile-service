<?php
require('init.php');
$comment = $_POST['comment'];
$author = $_POST['author'];
$rate = $_POST['rate'];
$date = $_POST['date'];
$email = $_POST['email'];
$feedbackid = uniqid("fd");

$sql="INSERT INTO `feedbacks` (`feedbackid`, `comment`, `author`, `rate`, `date`, `email`) VALUES ('$feedbackid', '$comment', '$author', '$rate', '$date', '$email')";
$result=mysqli_query($conn,$sql);

$res = array();
if($result){
$res['success']=true;
$res['message']="Thanks for your feedback";
}else{
$res['success']=false;
$res['message']="Failed to record your feedback";
$res['error'] = mysqli_connect_error();
$res['sql']=$sql;
}
echo json_encode($res);
?>
<?php
require('init.php');
$role = $_POST['role'];
$userId = $_POST['userid'];
$oldpass = $_POST['oldpassword'];
$newpass = $_POST['newpassword'];
$mdold = md5($oldpass);
$mdnew = md5($newpass);
$res = array();
$sql="";

if($role == "admin"){
    $sql = "UPDATE `admin` SET `password`='$mdnew' WHERE `adminid`='$userId' and password = '$mdold'";
}else if($role == "manager"){
    $sql = "UPDATE `managers` SET `password`='$mdnew' WHERE `managerid`='$userId' and password = '$mdold'";
}else if($role == "customer"){
    $sql = "UPDATE `customers` SET `password`='$mdnew' WHERE `customerid`='$userId' and password = '$mdold'";
}


$result=mysqli_query($conn,$sql);


if($result){
 
$res['success']=true;
$res['message']="Password changed";
}else{
$res['success']=false;
$res['message']="Failed to change password";
$res['error']= mysqli_connect_error();
}
echo json_encode($res);

?>


